<?php

require_once "dbconnect.php";

$id=$_POST['id'];
$password=$_POST['password'];
$name=$_POST['name'];
$phoneno=$_POST['phoneno'];
$email=$_POST['email'];
$address=$_POST['address'];


$sql="INSERT INTO customer (id, name, phone, mail_id, address, password) VALUES ('$id','$name','$phoneno','$email','$address','$password')";

  

if (mysqli_query($connection, $sql)){
            header('Location: login.html');
        }

?>