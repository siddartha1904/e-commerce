
<!DOCTYPE html>
<html>
    <head>
        <title>
            Display Category
        </title>
        <link rel="stylesheet" href="display_category.css" >
    </head>
    <style>
    .logout{
            width: 5%;
            margin-top: 1%;
            margin-left: auto; 
            margin-right: 0;
        }
        
        .update{
            width: 15%;
            margin-top: 1%;
            margin-left: auto; 
            margin-right: 0;
        }    
    .btn{
  width: 100%;
  padding: 8px 10px;
  font-size: 15px; 
  border: 0px;
  background:  #002116;
  color: #fff;
  cursor: pointer;
  border-radius: 5px;
  outline: none;
  margin: 0.5%;
}
.btn:hover{
  background: #ff6356;
}

    </style>

    <body>
    <center>
            <h1><?php
        session_start();
        // logout
        if(isset($_POST['but_logout'])){
            session_destroy();
            header('Location: login.html');
        }
        echo "Welcome ".$_SESSION['name']." !!";
        ?>
        </h1>
    </center>
                   
        <form method='post' action="" class="logout">
            <input class="btn" type="submit" value="Logout" name="but_logout">
        </form>
        <div class="update">
        <a href="update_customer_information.php"><input class="btn" type="submit" value="Update Customer Details" name="update"></a>
    </div>
        
        

        <div class="wrapper">

            
            <div class="form">
                <h1 class="title">
                    Select Category To be Displayed
                </h1>

                <form method='post' action="display_category2.php">
                    <div class="input_field">

                        
                        <label for="category">Select Category</label>
                        <select name="category" id="category" class="combo">
                            <option value="" disabled selected>Choose Category</option>
                            <option value="Mobiles">Mobiles</option>
                            <option value="Laptops">Laptops</option>
                            <option value="Cameras">Cameras</option>
                            <option value="Head Phones">Head Phones</option>
                            <option value="Smart watch">Smart watch</option>
                            
                          </select>

                    </div>

                   

                    
                    <div class="input_field">
                        <button type="submit" class="btn">Display</button>
                    </div>
                    

                    

                </form>
            </div>


        </div>

    </body>
</html>

