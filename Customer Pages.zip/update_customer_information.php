<!DOCTYPE html>
<html>
    <head>
        <title>
            Update Customer Information
        </title>
        <link rel="stylesheet" href="update_customer_information.css" >
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        
        
    </head>

    


    <body>
        <center>
            <h1>
        
                <?php
                session_start();
                // logout
                if(isset($_POST['but_logout'])){
                    session_destroy();
                    header('Location: login.html');
                }
                echo "Welcome ".$_SESSION['name']." !!";
                ?>


        </h1>
        </center>

        <script>
    
            function validate(){
                
                
                var password = document.forms["myform"]["password"].value;
                
                var phoneno = document.forms["myform"]["phoneno"].value;
                var Email = document.forms["myform"]["email"].value;
                var address = document.forms["myform"]["address"].value;
    
                if (phoneno == "" || phoneno == null || isNaN(phoneno) || phoneno.length > 10 || phoneno.length < 10 ){
                    swal("Invalid Contact number!", "Enter a valid phone Number", "warning");
                    
                    return false;
                }
                else if (Email == "" || Email == null){
                    swal("Enter a valid Email address");
                    return false;
                }else if (address == "" || address == null){
                    swal("Enter a valid address");
                    return false;
                }
                else if (password.length < 8 || password.search(/[a-z]/i) < 0 ||password.search(/[0-9]/) < 0){
                    swal("Invalid Password Type!", "Your password must be at least 8 characters,\n contain at least one letter and\n contain at least one digit.", "warning");
                   
                    return false;
                }
                
            }
        </script>

        <div class="wrapper">

            
            <div class="form">
                <h1 class="title">
                    Update Customer Information
                </h1>

                <form  class="validation" name="myform" onsubmit="return validate()" method='POST' action="update_customer_information2.php">
            
                    <div class="input_field">
                        <label for="phoneno">Enter new Phone Number : </label>
                        <input class="input" type="text" id="phoneno" name="phoneno" >
                    </div>

                    <div class="input_field">
                        <label for="email">Enter new Email : </label>
                        <input class="input" type="email" id="email" name="email" >
                    </div>

                    <div class="input_field">
                        <label for="address">Enter new Address : </label>
                        <input class="input" type="text" id="address" name="address" >
                    </div>

                    <div class="input_field">
                        <label for="password">Enter new Password : </label>
                        <input class="input" type="password" id="password" name="password" >
                    </div>

                

                    <div class="input_field">
                        <button type="submit" class="btn">Update</button>
                    </div>
                    

                    
        
                </form>
            </div>


        </div>

    </body>
</html>