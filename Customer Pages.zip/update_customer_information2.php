


<?php

require_once "dbconnect.php";
session_start();
echo "Welcome ".$_SESSION['name']." !!";
        
        


$id=$_SESSION['id'];
$phoneno=$_POST['phoneno'];
$email=$_POST['email'];
$address=$_POST['address'];
$password=$_POST['password'];


$sql="UPDATE customer set phone='$phoneno', mail_id='$email', address='$address', password='$password' WHERE id='$id'";
if (mysqli_query($connection, $sql)){ 
            header('Location: display_category.php');
        }

?>